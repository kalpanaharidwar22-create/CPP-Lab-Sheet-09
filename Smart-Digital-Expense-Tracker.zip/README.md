# Smart Digital Expense Tracker with Budget Prediction

**Course:** BCA I Semester (Session 2026-2027)  
**Language:** C++

## Objective
To record daily expenses, categorize spending, monitor monthly budgets, and predict whether the monthly budget may be exceeded.

## Features
1. User registration
2. Login system
3. Add daily expense
4. View expense history
5. Category-wise expense report
6. Monthly expense report
7. Set monthly budget
8. Budget warning at 80% and above
9. Month-end expense prediction using daily average
10. Search expense by date, category, or description
11. Delete expense by ID
12. File saving

## Files created automatically
- `users.txt` — registered usernames and passwords
- `expenses.txt` — saved expenses
- `budgets.txt` — monthly budgets

Keep these text files in the same folder as the program when running it.

## How to compile and run
Using g++:

```bash
g++ expense_tracker.cpp -o expense_tracker
./expense_tracker
```

On Windows:

```bash
g++ expense_tracker.cpp -o expense_tracker.exe
expense_tracker.exe
```

You can also paste the code into an online C++ compiler such as OnlineGDB and run it.

## Concepts used
Variables, loops, structures, vectors (dynamic arrays), functions, strings, searching, sorting, conditional statements, and file handling.

## Note
This is an educational demonstration. Passwords are stored as plain text in the local text file; do not use real or reused passwords. The prediction is a simple estimate based on spending so far divided by the current day of the month.
